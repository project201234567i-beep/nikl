import { NextRequest, NextResponse } from "next/server";
import {
  getAttendanceRecords,
  addAttendanceRecord,
  checkDuplicateAttendance,
  getAttendanceStats,
} from "@/lib/attendance-store";

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const includeStats = searchParams.get("stats") === "true";

  const records = getAttendanceRecords();

  if (includeStats) {
    const stats = getAttendanceStats();
    return NextResponse.json({ records, stats });
  }

  return NextResponse.json({ records });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { employeeName, employeeId, checkInTime, latitude, longitude, notes } =
      body;

    if (!employeeName || !employeeId || !checkInTime) {
      return NextResponse.json(
        { error: "Missing required fields: employeeName, employeeId, checkInTime" },
        { status: 400 }
      );
    }

    const today = new Date().toISOString().split("T")[0];

    // Check for duplicate attendance
    if (checkDuplicateAttendance(employeeId, today)) {
      return NextResponse.json(
        { error: "Attendance already recorded for this employee today" },
        { status: 409 }
      );
    }

    // Determine status based on check-in time (late if after 9:00 AM)
    const [hours] = checkInTime.split(":").map(Number);
    const status = hours >= 9 ? "late" : "present";

    const newRecord = addAttendanceRecord({
      employeeName,
      employeeId,
      date: today,
      checkInTime,
      latitude,
      longitude,
      status,
      notes,
    });

    return NextResponse.json({ record: newRecord }, { status: 201 });
  } catch {
    return NextResponse.json(
      { error: "Invalid request body" },
      { status: 400 }
    );
  }
}
