import { NextRequest, NextResponse } from "next/server";
import {
  getAttendanceById,
  updateAttendanceRecord,
  deleteAttendanceRecord,
} from "@/lib/attendance-store";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const record = getAttendanceById(id);

  if (!record) {
    return NextResponse.json(
      { error: "Attendance record not found" },
      { status: 404 }
    );
  }

  return NextResponse.json({ record });
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();

    const updatedRecord = updateAttendanceRecord(id, body);

    if (!updatedRecord) {
      return NextResponse.json(
        { error: "Attendance record not found" },
        { status: 404 }
      );
    }

    return NextResponse.json({ record: updatedRecord });
  } catch {
    return NextResponse.json(
      { error: "Invalid request body" },
      { status: 400 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const deleted = deleteAttendanceRecord(id);

  if (!deleted) {
    return NextResponse.json(
      { error: "Attendance record not found" },
      { status: 404 }
    );
  }

  return NextResponse.json({ message: "Record deleted successfully" });
}
