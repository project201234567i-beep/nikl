import { Header } from "@/components/header";
import { AttendanceForm } from "@/components/attendance-form";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-12">
        <AttendanceForm />
      </main>
    </div>
  );
}
