"use client";

import { useEffect, useRef, useState } from "react";

export function CyberBackground() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [mousePosition, setMousePosition] = useState({ x: 0.5, y: 0.5 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        setMousePosition({
          x: (e.clientX - rect.left) / rect.width,
          y: (e.clientY - rect.top) / rect.height,
        });
      }
    };

    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  const parallaxX = (mousePosition.x - 0.5) * 30;
  const parallaxY = (mousePosition.y - 0.5) * 30;

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 overflow-hidden bg-[#030712]"
      style={{ perspective: "1000px" }}
    >
      {/* Base gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#030712] via-[#0a1628] to-[#030712]" />

      {/* Animated mesh gradient */}
      <div
        className="absolute inset-0 opacity-40"
        style={{
          background: `
            radial-gradient(ellipse 80% 50% at ${30 + parallaxX * 0.5}% ${40 + parallaxY * 0.5}%, rgba(6, 182, 212, 0.15) 0%, transparent 50%),
            radial-gradient(ellipse 60% 40% at ${70 - parallaxX * 0.3}% ${60 - parallaxY * 0.3}%, rgba(20, 184, 166, 0.12) 0%, transparent 50%),
            radial-gradient(ellipse 50% 60% at ${50 + parallaxX * 0.2}% ${80 + parallaxY * 0.2}%, rgba(16, 185, 129, 0.1) 0%, transparent 50%)
          `,
        }}
      />

      {/* Grid lines */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `
            linear-gradient(rgba(6, 182, 212, 0.5) 1px, transparent 1px),
            linear-gradient(90deg, rgba(6, 182, 212, 0.5) 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
          transform: `translate(${parallaxX * 0.5}px, ${parallaxY * 0.5}px)`,
        }}
      />

      {/* Floating orbs - Layer 1 (far) */}
      <div
        className="absolute w-96 h-96 rounded-full blur-[100px] animate-float-slow"
        style={{
          background: "radial-gradient(circle, rgba(6, 182, 212, 0.2) 0%, transparent 70%)",
          top: "10%",
          left: "10%",
          transform: `translate(${parallaxX * -0.8}px, ${parallaxY * -0.8}px)`,
        }}
      />
      <div
        className="absolute w-80 h-80 rounded-full blur-[80px] animate-float-medium"
        style={{
          background: "radial-gradient(circle, rgba(20, 184, 166, 0.15) 0%, transparent 70%)",
          bottom: "20%",
          right: "15%",
          transform: `translate(${parallaxX * -0.6}px, ${parallaxY * -0.6}px)`,
        }}
      />
      <div
        className="absolute w-64 h-64 rounded-full blur-[60px] animate-float-fast"
        style={{
          background: "radial-gradient(circle, rgba(16, 185, 129, 0.12) 0%, transparent 70%)",
          top: "60%",
          left: "60%",
          transform: `translate(${parallaxX * -0.4}px, ${parallaxY * -0.4}px)`,
        }}
      />

      {/* 3D Rotating cube - wireframe */}
      <div
        className="absolute top-[15%] left-[15%] w-20 h-20 animate-rotate-3d"
        style={{
          transformStyle: "preserve-3d",
          transform: `translate(${parallaxX * 1.5}px, ${parallaxY * 1.5}px) rotateX(45deg) rotateY(45deg)`,
        }}
      >
        {[...Array(12)].map((_, i) => (
          <div
            key={i}
            className="absolute bg-gradient-to-r from-cyan-500/30 to-teal-500/30"
            style={{
              width: i < 4 ? "80px" : "2px",
              height: i < 4 ? "2px" : i < 8 ? "80px" : "2px",
              transformOrigin: "center",
              transform: `
                ${i === 0 ? "translateZ(40px) translateY(-40px)" : ""}
                ${i === 1 ? "translateZ(40px) translateY(40px)" : ""}
                ${i === 2 ? "translateZ(-40px) translateY(-40px)" : ""}
                ${i === 3 ? "translateZ(-40px) translateY(40px)" : ""}
                ${i === 4 ? "translateZ(40px) translateX(-40px)" : ""}
                ${i === 5 ? "translateZ(40px) translateX(40px)" : ""}
                ${i === 6 ? "translateZ(-40px) translateX(-40px)" : ""}
                ${i === 7 ? "translateZ(-40px) translateX(40px)" : ""}
                ${i === 8 ? "translateX(-40px) translateY(-40px) rotateY(90deg)" : ""}
                ${i === 9 ? "translateX(40px) translateY(-40px) rotateY(90deg)" : ""}
                ${i === 10 ? "translateX(-40px) translateY(40px) rotateY(90deg)" : ""}
                ${i === 11 ? "translateX(40px) translateY(40px) rotateY(90deg)" : ""}
              `,
              boxShadow: "0 0 10px rgba(6, 182, 212, 0.5)",
            }}
          />
        ))}
      </div>

      {/* 3D Rotating ring */}
      <div
        className="absolute bottom-[25%] right-[20%] w-32 h-32 animate-rotate-ring"
        style={{
          transformStyle: "preserve-3d",
          transform: `translate(${parallaxX * 1.2}px, ${parallaxY * 1.2}px)`,
        }}
      >
        {[...Array(24)].map((_, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 rounded-full bg-teal-400/40"
            style={{
              left: "50%",
              top: "50%",
              transform: `rotateY(${i * 15}deg) translateZ(60px) translateX(-50%) translateY(-50%)`,
              boxShadow: "0 0 8px rgba(20, 184, 166, 0.6)",
            }}
          />
        ))}
      </div>

      {/* Holographic lines */}
      <svg
        className="absolute inset-0 w-full h-full opacity-20"
        style={{ transform: `translate(${parallaxX * 0.3}px, ${parallaxY * 0.3}px)` }}
      >
        <defs>
          <linearGradient id="lineGrad1" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="transparent" />
            <stop offset="50%" stopColor="rgba(6, 182, 212, 0.8)" />
            <stop offset="100%" stopColor="transparent" />
          </linearGradient>
          <linearGradient id="lineGrad2" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="transparent" />
            <stop offset="50%" stopColor="rgba(20, 184, 166, 0.6)" />
            <stop offset="100%" stopColor="transparent" />
          </linearGradient>
        </defs>
        <line x1="0" y1="30%" x2="100%" y2="35%" stroke="url(#lineGrad1)" strokeWidth="1" className="animate-pulse-slow" />
        <line x1="0" y1="70%" x2="100%" y2="65%" stroke="url(#lineGrad1)" strokeWidth="1" className="animate-pulse-slow" style={{ animationDelay: "1s" }} />
        <line x1="20%" y1="0" x2="25%" y2="100%" stroke="url(#lineGrad2)" strokeWidth="1" className="animate-pulse-slow" style={{ animationDelay: "0.5s" }} />
        <line x1="75%" y1="0" x2="80%" y2="100%" stroke="url(#lineGrad2)" strokeWidth="1" className="animate-pulse-slow" style={{ animationDelay: "1.5s" }} />
      </svg>

      {/* Floating particles */}
      <div className="absolute inset-0">
        {[...Array(40)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full animate-float-particle"
            style={{
              width: `${2 + Math.random() * 4}px`,
              height: `${2 + Math.random() * 4}px`,
              background: i % 3 === 0 
                ? "rgba(6, 182, 212, 0.6)" 
                : i % 3 === 1 
                ? "rgba(20, 184, 166, 0.5)" 
                : "rgba(16, 185, 129, 0.4)",
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${8 + Math.random() * 7}s`,
              boxShadow: `0 0 ${6 + Math.random() * 6}px currentColor`,
              transform: `translate(${parallaxX * (0.5 + Math.random())}px, ${parallaxY * (0.5 + Math.random())}px)`,
            }}
          />
        ))}
      </div>

      {/* Digital mesh wave */}
      <div
        className="absolute bottom-0 left-0 right-0 h-48 opacity-30"
        style={{
          background: `
            repeating-linear-gradient(
              90deg,
              transparent,
              transparent 29px,
              rgba(6, 182, 212, 0.1) 29px,
              rgba(6, 182, 212, 0.1) 30px
            )
          `,
          transform: `perspective(500px) rotateX(60deg) translateY(${parallaxY * 0.5}px)`,
          transformOrigin: "bottom",
          maskImage: "linear-gradient(to top, black, transparent)",
        }}
      />

      {/* Floating glassmorphism shapes */}
      <div
        className="absolute top-[35%] right-[8%] w-24 h-24 rounded-2xl animate-float-glass border border-white/10"
        style={{
          background: "linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%)",
          backdropFilter: "blur(10px)",
          transform: `translate(${parallaxX * 2}px, ${parallaxY * 2}px) rotate(15deg)`,
          boxShadow: "0 8px 32px rgba(6, 182, 212, 0.1), inset 0 0 0 1px rgba(255,255,255,0.05)",
        }}
      />
      <div
        className="absolute bottom-[35%] left-[8%] w-16 h-16 rounded-xl animate-float-glass-reverse border border-white/10"
        style={{
          background: "linear-gradient(135deg, rgba(255,255,255,0.04) 0%, rgba(255,255,255,0.01) 100%)",
          backdropFilter: "blur(8px)",
          transform: `translate(${parallaxX * 1.8}px, ${parallaxY * 1.8}px) rotate(-10deg)`,
          animationDelay: "2s",
          boxShadow: "0 8px 32px rgba(20, 184, 166, 0.1), inset 0 0 0 1px rgba(255,255,255,0.05)",
        }}
      />
      <div
        className="absolute top-[65%] left-[25%] w-12 h-12 rounded-lg animate-float-glass border border-white/10"
        style={{
          background: "linear-gradient(135deg, rgba(255,255,255,0.03) 0%, rgba(255,255,255,0.01) 100%)",
          backdropFilter: "blur(6px)",
          transform: `translate(${parallaxX * 1.5}px, ${parallaxY * 1.5}px) rotate(25deg)`,
          animationDelay: "1s",
          boxShadow: "0 8px 32px rgba(16, 185, 129, 0.1), inset 0 0 0 1px rgba(255,255,255,0.05)",
        }}
      />

      {/* Second rotating cube - smaller, different position */}
      <div
        className="absolute bottom-[15%] left-[25%] w-12 h-12 animate-rotate-3d-reverse"
        style={{
          transformStyle: "preserve-3d",
          transform: `translate(${parallaxX * 1.3}px, ${parallaxY * 1.3}px)`,
          animationDuration: "25s",
        }}
      >
        {[0, 1, 2, 3, 4, 5].map((i) => (
          <div
            key={i}
            className="absolute w-12 h-12 border border-emerald-500/20"
            style={{
              transform: `
                ${i === 0 ? "translateZ(24px)" : ""}
                ${i === 1 ? "translateZ(-24px)" : ""}
                ${i === 2 ? "rotateY(90deg) translateZ(24px)" : ""}
                ${i === 3 ? "rotateY(90deg) translateZ(-24px)" : ""}
                ${i === 4 ? "rotateX(90deg) translateZ(24px)" : ""}
                ${i === 5 ? "rotateX(90deg) translateZ(-24px)" : ""}
              `,
              background: "rgba(16, 185, 129, 0.03)",
              boxShadow: "inset 0 0 20px rgba(16, 185, 129, 0.1)",
            }}
          />
        ))}
      </div>

      {/* Ambient glow overlay */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `radial-gradient(circle at ${mousePosition.x * 100}% ${mousePosition.y * 100}%, rgba(6, 182, 212, 0.05) 0%, transparent 50%)`,
          transition: "background 0.3s ease-out",
        }}
      />

      {/* Vignette */}
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_at_center,transparent_0%,rgba(0,0,0,0.4)_100%)]" />
    </div>
  );
}
