"use client";

import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Lock, Eye, EyeOff, ShieldCheck, Fingerprint } from "lucide-react";
import { CyberBackground } from "./cyber-background";

interface AdminLoginProps {
  onLogin: () => void;
}

// Default admin credentials
const ADMIN_USERNAME = "admin";
const ADMIN_PASSWORD = "admin123";

export function AdminLogin({ onLogin }: AdminLoginProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [focused, setFocused] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    // Simulate a small delay for UX
    await new Promise((resolve) => setTimeout(resolve, 800));

    if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
      // Store auth in sessionStorage
      sessionStorage.setItem("admin_authenticated", "true");
      onLogin();
    } else {
      setError("Invalid username or password");
    }
    setLoading(false);
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <CyberBackground />
      
      {/* Login card */}
      <div className="relative z-10 w-full max-w-md px-4">
        {/* Glow effect behind card */}
        <div className="absolute -inset-4 bg-gradient-to-r from-cyan-500/20 via-teal-500/20 to-emerald-500/20 rounded-3xl blur-2xl opacity-50" />
        
        <Card className="relative border-white/10 bg-black/40 backdrop-blur-xl shadow-2xl overflow-hidden">
          {/* Card top glow line */}
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-cyan-400/50 to-transparent" />
          
          {/* Animated corner accents */}
          <div className="absolute top-0 left-0 w-16 h-16 border-l-2 border-t-2 border-cyan-500/30 rounded-tl-xl" />
          <div className="absolute top-0 right-0 w-16 h-16 border-r-2 border-t-2 border-teal-500/30 rounded-tr-xl" />
          <div className="absolute bottom-0 left-0 w-16 h-16 border-l-2 border-b-2 border-emerald-500/30 rounded-bl-xl" />
          <div className="absolute bottom-0 right-0 w-16 h-16 border-r-2 border-b-2 border-cyan-500/30 rounded-br-xl" />
          
          <CardHeader className="text-center pb-2 pt-8">
            {/* Premium icon container */}
            <div className="mx-auto mb-6 relative">
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-500 to-teal-500 rounded-full blur-xl opacity-50 animate-pulse" />
              <div className="relative flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-cyan-500/20 to-teal-500/20 border border-white/10 backdrop-blur-sm">
                <div className="absolute inset-1 rounded-full bg-gradient-to-br from-gray-900/80 to-black/80" />
                <ShieldCheck className="relative h-9 w-9 text-cyan-400" />
                
                {/* Rotating ring around icon */}
                <div className="absolute inset-0 rounded-full border border-dashed border-cyan-500/30 animate-[spin_20s_linear_infinite]" />
              </div>
            </div>
            
            <CardTitle className="text-2xl font-bold bg-gradient-to-r from-white via-cyan-100 to-white bg-clip-text text-transparent">
              Admin Portal
            </CardTitle>
            <CardDescription className="text-gray-400 mt-2">
              Secure authentication required
            </CardDescription>
            
            {/* Security badge */}
            <div className="flex items-center justify-center gap-2 mt-4">
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-xs text-cyan-400">
                <Fingerprint className="h-3 w-3" />
                <span>256-bit Encrypted</span>
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="pb-8 pt-4">
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="username" className="text-gray-300 text-sm font-medium">
                  Username
                </Label>
                <div className="relative group">
                  <div className={`absolute -inset-0.5 bg-gradient-to-r from-cyan-500 to-teal-500 rounded-lg blur opacity-0 transition-opacity duration-300 ${focused === 'username' ? 'opacity-30' : 'group-hover:opacity-20'}`} />
                  <Input
                    id="username"
                    type="text"
                    placeholder="Enter username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    onFocus={() => setFocused('username')}
                    onBlur={() => setFocused(null)}
                    required
                    autoComplete="username"
                    className="relative bg-white/5 border-white/10 text-white placeholder:text-gray-500 focus:border-cyan-500/50 focus:ring-cyan-500/20 transition-all duration-300"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="password" className="text-gray-300 text-sm font-medium">
                  Password
                </Label>
                <div className="relative group">
                  <div className={`absolute -inset-0.5 bg-gradient-to-r from-cyan-500 to-teal-500 rounded-lg blur opacity-0 transition-opacity duration-300 ${focused === 'password' ? 'opacity-30' : 'group-hover:opacity-20'}`} />
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    onFocus={() => setFocused('password')}
                    onBlur={() => setFocused(null)}
                    required
                    autoComplete="current-password"
                    className="relative pr-10 bg-white/5 border-white/10 text-white placeholder:text-gray-500 focus:border-cyan-500/50 focus:ring-cyan-500/20 transition-all duration-300"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-cyan-400 transition-colors"
                    tabIndex={-1}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                </div>
              </div>

              {error && (
                <div className="rounded-lg bg-red-500/10 border border-red-500/20 p-3 text-sm text-red-400 flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-red-500 animate-pulse" />
                  {error}
                </div>
              )}

              <Button 
                type="submit" 
                className="w-full h-12 bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-black font-semibold shadow-lg shadow-cyan-500/25 transition-all duration-300 hover:shadow-cyan-500/40 hover:scale-[1.02] active:scale-[0.98]" 
                disabled={loading}
              >
                {loading ? (
                  <>
                    <div className="mr-2 h-4 w-4 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                    Authenticating...
                  </>
                ) : (
                  <>
                    <Lock className="mr-2 h-4 w-4" />
                    Access Dashboard
                  </>
                )}
              </Button>
            </form>
            
            {/* Bottom security indicator */}
            <div className="mt-6 pt-4 border-t border-white/5">
              <div className="flex items-center justify-center gap-2 text-xs text-gray-500">
                <div className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span>Secure connection established</span>
              </div>
            </div>
          </CardContent>
          
          {/* Card bottom glow line */}
          <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-teal-400/30 to-transparent" />
        </Card>
      </div>
    </div>
  );
}
