"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Clock, CheckCircle2, AlertCircle, Loader2, Fingerprint } from "lucide-react";
import { CyberBackground } from "./cyber-background";
import { LiveLocationMap } from "./live-location-map";

interface LocationData {
  latitude: number;
  longitude: number;
  accuracy: number;
  timestamp: number;
  address?: string;
  error?: string;
}

export function AttendanceForm() {
  const [employeeName, setEmployeeName] = useState("");
  const [employeeId, setEmployeeId] = useState("");
  const [notes, setNotes] = useState("");
  const [location, setLocation] = useState<LocationData | null>(null);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentTime, setCurrentTime] = useState<Date | null>(null);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    setCurrentTime(new Date());
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const handleLocationUpdate = (newLocation: LocationData | null) => {
    setLocation(newLocation);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const now = currentTime || new Date();
    const checkInTime = `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}`;

    try {
      const res = await fetch("/api/attendance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          employeeName,
          employeeId,
          checkInTime,
          latitude: location?.latitude,
          longitude: location?.longitude,
          address: location?.address,
          accuracy: location?.accuracy,
          notes: notes || undefined,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Failed to submit attendance");
      }

      setSuccess(true);
      setEmployeeName("");
      setEmployeeId("");
      setNotes("");
      setLocation(null);

      setTimeout(() => setSuccess(false), 5000);
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred");
    } finally {
      setLoading(false);
    }
  };

  const formatTime = (date: Date) => {
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const seconds = date.getSeconds();
    return {
      hours: hours.toString().padStart(2, "0"),
      minutes: minutes.toString().padStart(2, "0"),
      seconds: seconds.toString().padStart(2, "0"),
      period: hours >= 12 ? "PM" : "AM",
    };
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const timeData = currentTime ? formatTime(currentTime) : null;

  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      <CyberBackground />
      
      <div className="relative z-10 flex min-h-screen flex-col items-center justify-start px-4 py-8">
        {/* Premium Time Display Card */}
        <div className="mb-6 w-full max-w-lg">
          <div
            className="relative overflow-hidden rounded-2xl border border-white/10 p-6"
            style={{
              background: "linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%)",
              backdropFilter: "blur(20px)",
              boxShadow: `
                0 0 0 1px rgba(255,255,255,0.05) inset,
                0 20px 50px rgba(0,0,0,0.5),
                0 0 100px rgba(6, 182, 212, 0.1)
              `,
            }}
          >
            {/* Animated corner accents */}
            <div className="absolute top-0 left-0 w-12 h-12">
              <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-cyan-400 to-transparent" />
              <div className="absolute top-0 left-0 h-full w-[2px] bg-gradient-to-b from-cyan-400 to-transparent" />
            </div>
            <div className="absolute top-0 right-0 w-12 h-12">
              <div className="absolute top-0 right-0 w-full h-[2px] bg-gradient-to-l from-teal-400 to-transparent" />
              <div className="absolute top-0 right-0 h-full w-[2px] bg-gradient-to-b from-teal-400 to-transparent" />
            </div>
            <div className="absolute bottom-0 left-0 w-12 h-12">
              <div className="absolute bottom-0 left-0 w-full h-[2px] bg-gradient-to-r from-emerald-400 to-transparent" />
              <div className="absolute bottom-0 left-0 h-full w-[2px] bg-gradient-to-t from-emerald-400 to-transparent" />
            </div>
            <div className="absolute bottom-0 right-0 w-12 h-12">
              <div className="absolute bottom-0 right-0 w-full h-[2px] bg-gradient-to-l from-cyan-400 to-transparent" />
              <div className="absolute bottom-0 right-0 h-full w-[2px] bg-gradient-to-t from-cyan-400 to-transparent" />
            </div>

            <div className="text-center">
              {/* Digital Clock Display */}
              <div className="flex items-center justify-center gap-1">
                {mounted && timeData ? (
                  <>
                    <div className="flex items-baseline gap-1">
                      <span 
                        className="text-6xl font-bold tracking-tight font-mono"
                        style={{
                          background: "linear-gradient(135deg, #ffffff 0%, #06b6d4 50%, #14b8a6 100%)",
                          WebkitBackgroundClip: "text",
                          WebkitTextFillColor: "transparent",
                          textShadow: "0 0 40px rgba(6, 182, 212, 0.5)",
                        }}
                      >
                        {timeData.hours}
                      </span>
                      <span className="text-4xl font-bold text-cyan-400 animate-pulse">:</span>
                      <span 
                        className="text-6xl font-bold tracking-tight font-mono"
                        style={{
                          background: "linear-gradient(135deg, #ffffff 0%, #14b8a6 50%, #10b981 100%)",
                          WebkitBackgroundClip: "text",
                          WebkitTextFillColor: "transparent",
                          textShadow: "0 0 40px rgba(20, 184, 166, 0.5)",
                        }}
                      >
                        {timeData.minutes}
                      </span>
                      <span className="text-4xl font-bold text-teal-400 animate-pulse">:</span>
                      <span 
                        className="text-4xl font-bold tracking-tight font-mono text-emerald-400/80"
                        style={{
                          textShadow: "0 0 30px rgba(16, 185, 129, 0.5)",
                        }}
                      >
                        {timeData.seconds}
                      </span>
                    </div>
                    <span className="ml-2 text-lg font-semibold text-cyan-400/80 self-center">
                      {timeData.period}
                    </span>
                  </>
                ) : (
                  <span className="text-6xl font-bold tracking-tight font-mono opacity-0">00:00:00</span>
                )}
              </div>
              
              <div className="mt-3 text-base text-white/60 tracking-wide">
                {mounted && currentTime ? formatDate(currentTime) : <span className="opacity-0">Loading...</span>}
              </div>

              {/* Live indicator */}
              <div className="mt-3 flex items-center justify-center gap-2">
                <div className="relative">
                  <div className="w-2 h-2 bg-emerald-400 rounded-full" />
                  <div className="absolute inset-0 w-2 h-2 bg-emerald-400 rounded-full animate-ping" />
                </div>
                <span className="text-xs text-emerald-400/80 uppercase tracking-widest font-medium">Live</span>
              </div>
            </div>
          </div>
        </div>

        {/* Main Form Container */}
        <div className="w-full max-w-lg space-y-6">
          {/* Premium Check-in Form Card */}
          <div
            className="relative overflow-hidden rounded-2xl border border-white/10"
            style={{
              background: "linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%)",
              backdropFilter: "blur(20px)",
              boxShadow: `
                0 0 0 1px rgba(255,255,255,0.05) inset,
                0 20px 50px rgba(0,0,0,0.5),
                0 0 100px rgba(6, 182, 212, 0.1)
              `,
            }}
          >
            {/* Glow effect behind card */}
            <div 
              className="absolute -inset-1 rounded-2xl opacity-20 blur-xl -z-10"
              style={{
                background: "linear-gradient(135deg, rgba(6, 182, 212, 0.4) 0%, rgba(20, 184, 166, 0.3) 50%, rgba(16, 185, 129, 0.4) 100%)",
              }}
            />

            <div className="relative p-6">
              {/* Header */}
              <div className="mb-5 text-center">
                <div className="inline-flex items-center justify-center w-14 h-14 rounded-xl mb-3 border border-cyan-500/30"
                  style={{
                    background: "linear-gradient(135deg, rgba(6, 182, 212, 0.2) 0%, rgba(20, 184, 166, 0.1) 100%)",
                    boxShadow: "0 0 30px rgba(6, 182, 212, 0.3), inset 0 0 20px rgba(6, 182, 212, 0.1)",
                  }}
                >
                  <Fingerprint className="w-7 h-7 text-cyan-400" />
                </div>
                <h2 
                  className="text-xl font-bold tracking-tight"
                  style={{
                    background: "linear-gradient(135deg, #ffffff 0%, #06b6d4 100%)",
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                  }}
                >
                  Employee Check-In
                </h2>
                <p className="mt-1.5 text-sm text-white/50">
                  Record attendance with live GPS verification
                </p>
              </div>

              {/* Success Message */}
              {success && (
                <div 
                  className="mb-5 flex items-center gap-3 rounded-xl p-4 border border-emerald-500/30"
                  style={{
                    background: "linear-gradient(135deg, rgba(16, 185, 129, 0.2) 0%, rgba(16, 185, 129, 0.1) 100%)",
                    boxShadow: "0 0 20px rgba(16, 185, 129, 0.2)",
                  }}
                >
                  <CheckCircle2 className="h-5 w-5 text-emerald-400" />
                  <span className="text-emerald-300">Attendance recorded successfully!</span>
                </div>
              )}

              {/* Error Message */}
              {error && (
                <div 
                  className="mb-5 flex items-center gap-3 rounded-xl p-4 border border-red-500/30"
                  style={{
                    background: "linear-gradient(135deg, rgba(239, 68, 68, 0.2) 0%, rgba(239, 68, 68, 0.1) 100%)",
                  }}
                >
                  <AlertCircle className="h-5 w-5 text-red-400" />
                  <span className="text-red-300">{error}</span>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Employee Name */}
                <div className="space-y-1.5">
                  <Label htmlFor="employeeName" className="text-white/80 text-sm font-medium">Full Name</Label>
                  <div className="relative group">
                    <Input
                      id="employeeName"
                      placeholder="Enter your full name"
                      value={employeeName}
                      onChange={(e) => setEmployeeName(e.target.value)}
                      required
                      className="h-11 border-white/10 bg-white/5 text-white placeholder:text-white/30 focus:border-cyan-500/50 focus:ring-cyan-500/20 transition-all duration-300"
                      style={{
                        boxShadow: "inset 0 2px 4px rgba(0,0,0,0.2)",
                      }}
                    />
                  </div>
                </div>

                {/* Employee ID */}
                <div className="space-y-1.5">
                  <Label htmlFor="employeeId" className="text-white/80 text-sm font-medium">Employee ID</Label>
                  <div className="relative group">
                    <Input
                      id="employeeId"
                      placeholder="e.g., EMP001"
                      value={employeeId}
                      onChange={(e) => setEmployeeId(e.target.value)}
                      required
                      className="h-11 border-white/10 bg-white/5 text-white placeholder:text-white/30 focus:border-cyan-500/50 focus:ring-cyan-500/20 transition-all duration-300"
                      style={{
                        boxShadow: "inset 0 2px 4px rgba(0,0,0,0.2)",
                      }}
                    />
                  </div>
                </div>

                {/* Notes */}
                <div className="space-y-1.5">
                  <Label htmlFor="notes" className="text-white/80 text-sm font-medium">Notes (Optional)</Label>
                  <Textarea
                    id="notes"
                    placeholder="Any additional notes..."
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="min-h-[70px] border-white/10 bg-white/5 text-white placeholder:text-white/30 focus:border-cyan-500/50 focus:ring-cyan-500/20 resize-none transition-all duration-300"
                    style={{
                      boxShadow: "inset 0 2px 4px rgba(0,0,0,0.2)",
                    }}
                    rows={2}
                  />
                </div>

                {/* Submit Button */}
                <Button
                  type="submit"
                  disabled={loading}
                  className="relative w-full h-12 text-base font-semibold overflow-hidden group transition-all duration-300"
                  style={{
                    background: "linear-gradient(135deg, #06b6d4 0%, #14b8a6 50%, #10b981 100%)",
                    boxShadow: "0 0 30px rgba(6, 182, 212, 0.4), 0 10px 40px rgba(6, 182, 212, 0.2)",
                  }}
                >
                  <div 
                    className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                    style={{
                      background: "linear-gradient(135deg, #14b8a6 0%, #10b981 50%, #06b6d4 100%)",
                    }}
                  />
                  <span className="relative flex items-center justify-center gap-2 text-white">
                    {loading ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Clock className="w-5 h-5" />
                        Check In Now
                      </>
                    )}
                  </span>
                </Button>
              </form>
            </div>
          </div>

          {/* Live Location Map Card */}
          <div
            className="relative overflow-hidden rounded-2xl border border-white/10"
            style={{
              background: "linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%)",
              backdropFilter: "blur(20px)",
              boxShadow: `
                0 0 0 1px rgba(255,255,255,0.05) inset,
                0 20px 50px rgba(0,0,0,0.5),
                0 0 100px rgba(6, 182, 212, 0.1)
              `,
            }}
          >
            <div className="relative p-6">
              <LiveLocationMap onLocationUpdate={handleLocationUpdate} />
            </div>
          </div>
        </div>
      </div>

      {/* Leaflet CSS */}
      <link
        rel="stylesheet"
        href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
        integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="
        crossOrigin=""
      />
    </div>
  );
}
