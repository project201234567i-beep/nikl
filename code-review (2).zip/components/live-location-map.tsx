"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import { MapPin, Navigation, RefreshCw, Shield, Wifi, WifiOff, Loader2, MapPinned, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import dynamic from "next/dynamic";

// Dynamically import the map to avoid SSR issues
const MapContainer = dynamic(
  () => import("react-leaflet").then((mod) => mod.MapContainer),
  { ssr: false }
);
const TileLayer = dynamic(
  () => import("react-leaflet").then((mod) => mod.TileLayer),
  { ssr: false }
);
const Marker = dynamic(
  () => import("react-leaflet").then((mod) => mod.Marker),
  { ssr: false }
);
const Circle = dynamic(
  () => import("react-leaflet").then((mod) => mod.Circle),
  { ssr: false }
);

interface LocationData {
  latitude: number;
  longitude: number;
  accuracy: number;
  timestamp: number;
  address?: string;
  error?: string;
}

interface LiveLocationMapProps {
  onLocationUpdate: (location: LocationData | null) => void;
  autoTrack?: boolean;
}

export function LiveLocationMap({ onLocationUpdate, autoTrack = false }: LiveLocationMapProps) {
  const [location, setLocation] = useState<LocationData | null>(null);
  const [loading, setLoading] = useState(false);
  const [tracking, setTracking] = useState(autoTrack);
  const [permissionStatus, setPermissionStatus] = useState<"granted" | "denied" | "prompt" | "unknown">("unknown");
  const [mapReady, setMapReady] = useState(false);
  const [leafletIcon, setLeafletIcon] = useState<L.Icon | null>(null);
  const watchIdRef = useRef<number | null>(null);
  const mapRef = useRef<L.Map | null>(null);

  // Initialize Leaflet icon on client side
  useEffect(() => {
    if (typeof window !== "undefined") {
      import("leaflet").then((L) => {
        // Fix default marker icon
        delete (L.Icon.Default.prototype as Record<string, unknown>)._getIconUrl;
        L.Icon.Default.mergeOptions({
          iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png",
          iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png",
          shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png",
        });

        const customIcon = L.icon({
          iconUrl: "data:image/svg+xml;base64," + btoa(`
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="40" height="40">
              <defs>
                <filter id="glow">
                  <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
                  <feMerge>
                    <feMergeNode in="coloredBlur"/>
                    <feMergeNode in="SourceGraphic"/>
                  </feMerge>
                </filter>
              </defs>
              <path fill="#14b8a6" filter="url(#glow)" d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
              <circle cx="12" cy="9" r="3" fill="#0d9488"/>
            </svg>
          `),
          iconSize: [40, 40],
          iconAnchor: [20, 40],
          popupAnchor: [0, -40],
        });
        setLeafletIcon(customIcon);
        setMapReady(true);
      });
    }
  }, []);

  // Check permission status
  useEffect(() => {
    if (typeof navigator !== "undefined" && navigator.permissions) {
      navigator.permissions.query({ name: "geolocation" }).then((result) => {
        setPermissionStatus(result.state as "granted" | "denied" | "prompt");
        result.onchange = () => {
          setPermissionStatus(result.state as "granted" | "denied" | "prompt");
        };
      }).catch(() => {
        setPermissionStatus("unknown");
      });
    }
  }, []);

  // Reverse geocoding
  const getAddress = useCallback(async (lat: number, lon: number): Promise<string> => {
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}&zoom=18&addressdetails=1`,
        {
          headers: {
            "Accept-Language": "en",
          },
        }
      );
      const data = await response.json();
      return data.display_name || "Address not found";
    } catch {
      return "Unable to fetch address";
    }
  }, []);

  // Get current location
  const getCurrentLocation = useCallback(async () => {
    if (!navigator.geolocation) {
      const errorLocation = {
        latitude: 0,
        longitude: 0,
        accuracy: 0,
        timestamp: Date.now(),
        error: "Geolocation not supported by your browser",
      };
      setLocation(errorLocation);
      onLocationUpdate(errorLocation);
      return;
    }

    setLoading(true);

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const address = await getAddress(position.coords.latitude, position.coords.longitude);
        const newLocation: LocationData = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
          timestamp: position.timestamp,
          address,
        };
        setLocation(newLocation);
        onLocationUpdate(newLocation);
        setLoading(false);

        // Pan map to new location
        if (mapRef.current) {
          mapRef.current.setView([newLocation.latitude, newLocation.longitude], 16, {
            animate: true,
            duration: 1,
          });
        }
      },
      (error) => {
        let errorMessage = "Unable to get location";
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = "Location permission denied";
            setPermissionStatus("denied");
            break;
          case error.POSITION_UNAVAILABLE:
            errorMessage = "Location unavailable";
            break;
          case error.TIMEOUT:
            errorMessage = "Location request timed out";
            break;
        }
        const errorLocation = {
          latitude: 0,
          longitude: 0,
          accuracy: 0,
          timestamp: Date.now(),
          error: errorMessage,
        };
        setLocation(errorLocation);
        onLocationUpdate(errorLocation);
        setLoading(false);
      },
      {
        enableHighAccuracy: true,
        timeout: 15000,
        maximumAge: 0,
      }
    );
  }, [getAddress, onLocationUpdate]);

  // Start/stop tracking
  const toggleTracking = useCallback(() => {
    if (tracking) {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = null;
      }
      setTracking(false);
    } else {
      setTracking(true);
      watchIdRef.current = navigator.geolocation.watchPosition(
        async (position) => {
          const address = await getAddress(position.coords.latitude, position.coords.longitude);
          const newLocation: LocationData = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
            timestamp: position.timestamp,
            address,
          };
          setLocation(newLocation);
          onLocationUpdate(newLocation);

          if (mapRef.current) {
            mapRef.current.setView([newLocation.latitude, newLocation.longitude], 16, {
              animate: true,
              duration: 0.5,
            });
          }
        },
        (error) => {
          console.error("Tracking error:", error);
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 5000,
        }
      );
    }
  }, [tracking, getAddress, onLocationUpdate]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
    };
  }, []);

  const formatTimestamp = (ts: number) => {
    return new Date(ts).toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
  };

  return (
    <div className="space-y-4">
      {/* Location Status Card */}
      <div className="relative rounded-xl overflow-hidden">
        {/* Glassmorphism background */}
        <div className="absolute inset-0 bg-gradient-to-br from-teal-500/10 via-cyan-500/5 to-emerald-500/10 backdrop-blur-xl" />
        <div className="absolute inset-0 border border-teal-500/20 rounded-xl" />
        
        {/* Animated glow border */}
        <div className="absolute inset-0 rounded-xl overflow-hidden">
          <div 
            className="absolute inset-0 opacity-50"
            style={{
              background: `linear-gradient(90deg, transparent, rgba(20, 184, 166, 0.3), transparent)`,
              animation: tracking ? "shimmer 2s infinite" : "none",
            }}
          />
        </div>

        <div className="relative p-4 space-y-4">
          {/* Header with status */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-teal-500/20 to-cyan-500/20 flex items-center justify-center border border-teal-500/30">
                  <Navigation className="w-5 h-5 text-teal-400" />
                </div>
                {tracking && (
                  <span className="absolute -top-1 -right-1 w-3 h-3 bg-teal-400 rounded-full animate-ping" />
                )}
              </div>
              <div>
                <h3 className="text-sm font-semibold text-foreground">Live GPS Tracking</h3>
                <p className="text-xs text-muted-foreground">
                  {tracking ? "Real-time tracking active" : "Click to get location"}
                </p>
              </div>
            </div>

            {/* Permission indicator */}
            <div className="flex items-center gap-2">
              {permissionStatus === "granted" ? (
                <div className="flex items-center gap-1.5 px-2 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30">
                  <Shield className="w-3 h-3 text-emerald-400" />
                  <span className="text-xs text-emerald-400">Secure</span>
                </div>
              ) : permissionStatus === "denied" ? (
                <div className="flex items-center gap-1.5 px-2 py-1 rounded-full bg-red-500/10 border border-red-500/30">
                  <WifiOff className="w-3 h-3 text-red-400" />
                  <span className="text-xs text-red-400">Denied</span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 px-2 py-1 rounded-full bg-amber-500/10 border border-amber-500/30">
                  <Wifi className="w-3 h-3 text-amber-400" />
                  <span className="text-xs text-amber-400">Pending</span>
                </div>
              )}
            </div>
          </div>

          {/* Coordinates display */}
          {location && !location.error && (
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 rounded-lg bg-black/30 border border-teal-500/20">
                <p className="text-xs text-muted-foreground mb-1">Latitude</p>
                <p className="text-sm font-mono text-teal-400">{location.latitude.toFixed(6)}</p>
              </div>
              <div className="p-3 rounded-lg bg-black/30 border border-teal-500/20">
                <p className="text-xs text-muted-foreground mb-1">Longitude</p>
                <p className="text-sm font-mono text-cyan-400">{location.longitude.toFixed(6)}</p>
              </div>
            </div>
          )}

          {/* Address */}
          {location?.address && !location.error && (
            <div className="p-3 rounded-lg bg-black/30 border border-teal-500/20">
              <div className="flex items-start gap-2">
                <MapPinned className="w-4 h-4 text-teal-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Current Address</p>
                  <p className="text-sm text-foreground leading-relaxed">{location.address}</p>
                </div>
              </div>
            </div>
          )}

          {/* Accuracy and timestamp */}
          {location && !location.error && (
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-teal-400 animate-pulse" />
                <span>Accuracy: {location.accuracy.toFixed(1)}m</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Clock className="w-3 h-3" />
                <span>{formatTimestamp(location.timestamp)}</span>
              </div>
            </div>
          )}

          {/* Error display */}
          {location?.error && (
            <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30">
              <p className="text-sm text-red-400">{location.error}</p>
              <p className="text-xs text-muted-foreground mt-1">
                Please enable location access in your browser settings.
              </p>
            </div>
          )}

          {/* Action buttons */}
          <div className="flex gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={getCurrentLocation}
              disabled={loading}
              className="flex-1 bg-black/30 border-teal-500/30 hover:bg-teal-500/10 hover:border-teal-500/50 text-foreground"
            >
              {loading ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin text-teal-400" />
              ) : (
                <MapPin className="w-4 h-4 mr-2 text-teal-400" />
              )}
              {loading ? "Locating..." : location && !location.error ? "Refresh" : "Get Location"}
            </Button>
            <Button
              type="button"
              variant={tracking ? "default" : "outline"}
              onClick={toggleTracking}
              className={tracking 
                ? "bg-teal-500 hover:bg-teal-600 text-teal-950" 
                : "bg-black/30 border-teal-500/30 hover:bg-teal-500/10 hover:border-teal-500/50 text-foreground"
              }
            >
              <RefreshCw className={`w-4 h-4 ${tracking ? "animate-spin" : ""}`} />
            </Button>
          </div>
        </div>
      </div>

      {/* Map container */}
      {location && !location.error && mapReady && (
        <div className="relative rounded-xl overflow-hidden h-64">
          {/* Glassmorphism border */}
          <div className="absolute inset-0 rounded-xl border border-teal-500/30 pointer-events-none z-10" />
          <div className="absolute inset-0 rounded-xl shadow-[0_0_30px_rgba(20,184,166,0.15)] pointer-events-none z-10" />
          
          {/* Pulse rings animation overlay */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-20">
            {tracking && (
              <>
                <div className="absolute w-16 h-16 rounded-full border-2 border-teal-400/30 animate-ping" style={{ animationDuration: "2s" }} />
                <div className="absolute w-24 h-24 rounded-full border border-teal-400/20 animate-ping" style={{ animationDuration: "3s" }} />
              </>
            )}
          </div>

          <MapContainer
            center={[location.latitude, location.longitude]}
            zoom={16}
            style={{ height: "100%", width: "100%" }}
            ref={(map) => { if (map) mapRef.current = map; }}
            zoomControl={false}
          >
            <TileLayer
              attribution='&copy; <a href="https://carto.com/">CARTO</a>'
              url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
            />
            {leafletIcon && (
              <Marker position={[location.latitude, location.longitude]} icon={leafletIcon} />
            )}
            <Circle
              center={[location.latitude, location.longitude]}
              radius={location.accuracy}
              pathOptions={{
                color: "#14b8a6",
                fillColor: "#14b8a6",
                fillOpacity: 0.1,
                weight: 2,
              }}
            />
          </MapContainer>

          {/* Dark overlay gradient */}
          <div className="absolute inset-0 bg-gradient-to-t from-background/50 via-transparent to-background/30 pointer-events-none z-10" />
        </div>
      )}

      {/* Loading placeholder for map */}
      {location && !location.error && !mapReady && (
        <div className="relative rounded-xl overflow-hidden h-64 bg-black/50 border border-teal-500/20 flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="w-8 h-8 text-teal-400 animate-spin mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">Loading map...</p>
          </div>
        </div>
      )}

      <style jsx>{`
        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
      `}</style>
    </div>
  );
}
