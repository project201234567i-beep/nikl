"use client";

import useSWR from "swr";
import { StatsCards } from "./stats-cards";
import { AttendanceTable } from "./attendance-table";
import { ExportButtons } from "./export-buttons";
import { Skeleton } from "@/components/ui/skeleton";
import { RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { AttendanceRecord, AttendanceStats } from "@/lib/types";

interface AttendanceResponse {
  records: AttendanceRecord[];
  stats: AttendanceStats;
}

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export function AdminDashboard() {
  const { data, error, isLoading, mutate } = useSWR<AttendanceResponse>(
    "/api/attendance?stats=true",
    fetcher,
    { refreshInterval: 30000 }
  );

  if (error) {
    return (
      <div className="flex h-64 items-center justify-center">
        <p className="text-destructive">Failed to load attendance data</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      {isLoading ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-28 rounded-lg" />
          ))}
        </div>
      ) : data?.stats ? (
        <StatsCards stats={data.stats} />
      ) : null}

      {/* Header with actions */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-lg font-semibold">Attendance Records</h2>
          <p className="text-sm text-muted-foreground">
            View and manage all employee attendance records
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => mutate()}
            disabled={isLoading}
          >
            <RefreshCw className={`mr-2 h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
            Refresh
          </Button>
          {data?.records && <ExportButtons records={data.records} />}
        </div>
      </div>

      {/* Table */}
      {isLoading ? (
        <Skeleton className="h-96 rounded-lg" />
      ) : data?.records ? (
        <AttendanceTable records={data.records} onUpdate={() => mutate()} />
      ) : null}
    </div>
  );
}
