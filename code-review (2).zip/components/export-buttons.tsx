"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { FileSpreadsheet, FileText, Loader2 } from "lucide-react";
import type { AttendanceRecord } from "@/lib/types";
import * as XLSX from "xlsx";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";

interface ExportButtonsProps {
  records: AttendanceRecord[];
}

export function ExportButtons({ records }: ExportButtonsProps) {
  const [exporting, setExporting] = useState<"excel" | "pdf" | null>(null);

  const exportToExcel = () => {
    setExporting("excel");
    try {
      const data = records.map((record) => ({
        "Employee Name": record.employeeName,
        "Employee ID": record.employeeId,
        Date: record.date,
        "Check In": record.checkInTime,
        "Check Out": record.checkOutTime || "-",
        Status: record.status === "present" ? "On Time" : "Late",
        Latitude: record.latitude?.toFixed(4) || "-",
        Longitude: record.longitude?.toFixed(4) || "-",
        Notes: record.notes || "-",
      }));

      const ws = XLSX.utils.json_to_sheet(data);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Attendance");

      // Auto-size columns
      const colWidths = Object.keys(data[0] || {}).map((key) => ({
        wch: Math.max(key.length, 15),
      }));
      ws["!cols"] = colWidths;

      XLSX.writeFile(wb, `attendance-${new Date().toISOString().split("T")[0]}.xlsx`);
    } finally {
      setExporting(null);
    }
  };

  const exportToPDF = () => {
    setExporting("pdf");
    try {
      const doc = new jsPDF();

      // Title
      doc.setFontSize(20);
      doc.setTextColor(40, 40, 40);
      doc.text("Attendance Report", 14, 22);

      // Date
      doc.setFontSize(10);
      doc.setTextColor(100, 100, 100);
      doc.text(`Generated: ${new Date().toLocaleString()}`, 14, 30);

      // Table
      const tableData = records.map((record) => [
        record.employeeName,
        record.employeeId,
        record.date,
        record.checkInTime,
        record.checkOutTime || "-",
        record.status === "present" ? "On Time" : "Late",
      ]);

      autoTable(doc, {
        startY: 38,
        head: [["Name", "ID", "Date", "Check In", "Check Out", "Status"]],
        body: tableData,
        theme: "striped",
        headStyles: {
          fillColor: [45, 182, 155],
          textColor: [20, 20, 20],
          fontStyle: "bold",
        },
        styles: {
          fontSize: 9,
          cellPadding: 3,
        },
        alternateRowStyles: {
          fillColor: [245, 245, 245],
        },
      });

      doc.save(`attendance-${new Date().toISOString().split("T")[0]}.pdf`);
    } finally {
      setExporting(null);
    }
  };

  return (
    <div className="flex items-center gap-2">
      <Button
        variant="outline"
        size="sm"
        onClick={exportToExcel}
        disabled={exporting !== null || records.length === 0}
      >
        {exporting === "excel" ? (
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
        ) : (
          <FileSpreadsheet className="mr-2 h-4 w-4 text-success" />
        )}
        Export Excel
      </Button>
      <Button
        variant="outline"
        size="sm"
        onClick={exportToPDF}
        disabled={exporting !== null || records.length === 0}
      >
        {exporting === "pdf" ? (
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
        ) : (
          <FileText className="mr-2 h-4 w-4 text-destructive" />
        )}
        Export PDF
      </Button>
    </div>
  );
}
