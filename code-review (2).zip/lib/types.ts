export interface AttendanceRecord {
  id: string;
  employeeName: string;
  employeeId: string;
  date: string;
  checkInTime: string;
  checkOutTime?: string;
  latitude?: number;
  longitude?: number;
  status: "present" | "late" | "absent";
  notes?: string;
}

export interface AttendanceStats {
  totalRecords: number;
  presentToday: number;
  lateToday: number;
  avgCheckInTime: string;
}
