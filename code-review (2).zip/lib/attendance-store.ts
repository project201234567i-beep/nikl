import { AttendanceRecord } from "./types";

// In-memory store for demo purposes
// In production, this would be a database
let attendanceRecords: AttendanceRecord[] = [
  {
    id: "1",
    employeeName: "John Smith",
    employeeId: "EMP001",
    date: new Date().toISOString().split("T")[0],
    checkInTime: "08:45",
    checkOutTime: "17:30",
    latitude: 40.7128,
    longitude: -74.006,
    status: "present",
    notes: "On time",
  },
  {
    id: "2",
    employeeName: "Sarah Johnson",
    employeeId: "EMP002",
    date: new Date().toISOString().split("T")[0],
    checkInTime: "09:15",
    checkOutTime: "17:45",
    latitude: 40.7129,
    longitude: -74.0055,
    status: "late",
    notes: "Traffic delay",
  },
  {
    id: "3",
    employeeName: "Michael Brown",
    employeeId: "EMP003",
    date: new Date().toISOString().split("T")[0],
    checkInTime: "08:30",
    latitude: 40.713,
    longitude: -74.005,
    status: "present",
  },
];

export function getAttendanceRecords(): AttendanceRecord[] {
  return [...attendanceRecords];
}

export function getAttendanceById(id: string): AttendanceRecord | undefined {
  return attendanceRecords.find((record) => record.id === id);
}

export function addAttendanceRecord(
  record: Omit<AttendanceRecord, "id">
): AttendanceRecord {
  const newRecord: AttendanceRecord = {
    ...record,
    id: Date.now().toString(),
  };
  attendanceRecords.push(newRecord);
  return newRecord;
}

export function updateAttendanceRecord(
  id: string,
  updates: Partial<AttendanceRecord>
): AttendanceRecord | null {
  const index = attendanceRecords.findIndex((record) => record.id === id);
  if (index === -1) return null;

  attendanceRecords[index] = { ...attendanceRecords[index], ...updates };
  return attendanceRecords[index];
}

export function deleteAttendanceRecord(id: string): boolean {
  const index = attendanceRecords.findIndex((record) => record.id === id);
  if (index === -1) return false;

  attendanceRecords.splice(index, 1);
  return true;
}

export function checkDuplicateAttendance(
  employeeId: string,
  date: string
): boolean {
  return attendanceRecords.some(
    (record) => record.employeeId === employeeId && record.date === date
  );
}

export function getAttendanceStats() {
  const today = new Date().toISOString().split("T")[0];
  const todayRecords = attendanceRecords.filter(
    (record) => record.date === today
  );

  const presentToday = todayRecords.filter(
    (r) => r.status === "present"
  ).length;
  const lateToday = todayRecords.filter((r) => r.status === "late").length;

  // Calculate average check-in time
  const checkInTimes = todayRecords.map((r) => {
    const [hours, minutes] = r.checkInTime.split(":").map(Number);
    return hours * 60 + minutes;
  });

  const avgMinutes =
    checkInTimes.length > 0
      ? Math.round(
          checkInTimes.reduce((a, b) => a + b, 0) / checkInTimes.length
        )
      : 0;
  const avgHours = Math.floor(avgMinutes / 60);
  const avgMins = avgMinutes % 60;
  const avgCheckInTime = `${avgHours.toString().padStart(2, "0")}:${avgMins.toString().padStart(2, "0")}`;

  return {
    totalRecords: attendanceRecords.length,
    presentToday,
    lateToday,
    avgCheckInTime,
  };
}
